package controller;

import java.awt.Window;

import javax.swing.JPanel;

import view.PainelPrincipal;

public class RetornaMain {

public static void retornaMain(JPanel panel){
	  
		PainelPrincipal p = new PainelPrincipal();
		p.setVisible(true);
		
	}
	
}
