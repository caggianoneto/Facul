/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import view.Principal.telaPrincipal;

/**
 *
 * @author NIB
 */
public class PrincipalTeste {
    
    public static void main(String[] args) {
        
        // criando um cliente teste
        //Cliente cliente1 = new Cliente("000000000-00", "João da Silva", "CNH 000", "Masculino");
        
        // criando um fornecedor
        //Fornecedor fornecedor1 = new Fornecedor("CNPJ 000000-00", "Razão Social", "Loja Chevrolet 1");
        
        // criando endereço do cliente1
        //Endereco EnderecoCliente1 = new Endereco(cliente1.getCodigo(), "Rua tal", "cep", "Cidade", "Estado");
        
        // crinado um veiculo
        
        //Veiculo astra1 = new Veiculo(fornecedor1.getNomeFantasia(),2010, Boolean.TRUE, "Chassi numero", "astra", "Chevrolet", "Azul");
        
        
        new telaPrincipal().setVisible(true);
        
        
        
    }
    
    
}
