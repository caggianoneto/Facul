package interfaces;

public interface ContaItf {
	public double saque(double valor);
	public double deposito(double valor);
}
