INSTALL PLUGIN mysql_firewall_users SONAME 'firewall.so';
INSTALL PLUGIN mysql_firewall_whitelist SONAME 'firewall.so';
INSTALL PLUGIN mysql_firewall SONAME 'firewall.so';
